﻿My Hand Is A Goose — Press Kit (placeholder)

Replace this archive with final logo, screenshots, and promo art before launch.
Contact: hello@myhandisagoose.example
